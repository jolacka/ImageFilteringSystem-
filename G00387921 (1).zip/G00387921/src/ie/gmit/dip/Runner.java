package ie.gmit.dip;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.awt.image.BufferedImage;

public class Runner {
	/*
	  IMPORTANT! Read the following points and delete them when you're finished.
	  --------------------------------------------------------------------------
	  (a) Keep the menu alive inside a loop. When (4) is selected, set the loop control variable to false.
	  (b) Use a java.util.Scanner class to read in the user input and a new switch statement to process the choice. You
	      can read about the new switch statement at https://docs.oracle.com/en/java/javase/13/language/switch-expressions.html.
	  (c) Perhaps consider placing the arrays in the classs Kernel.java into some type of enum, as the array values are constant.
	  (e) Try not to cram all the functionality into this one class! Each class should have one responsibility only.
	*/
	public static String menu = "0";
	public static String imageName = "bridge-gs.png";
	public static String filterName = "";
	public static double[][] kernel;
	public static Scanner input = new Scanner(System.in);  // Create a Scanner object

	public static void main(String[] args) {
		System.out.println(ConsoleColour.BLUE_BRIGHT);
		System.out.println("***************************************************");
		System.out.println("* GMIT - Dept. Computer Science & Applied Physics *");
		System.out.println("*                                                 *");
		System.out.println("*           Image Filtering System V0.1           *");
		System.out.println("*     H.Dip in Science (Software Development)     *");
		System.out.println("*                                                 *");
		System.out.println("***************************************************");

		while(!menu.equals("4")){
			printMenu();
			menu = input.nextLine();
			switch (menu) {
				case "1" -> {
					System.out.println(ConsoleColour.BLUE_BRIGHT);

					imageName = FileName.setFileName();
				}
				case "2" -> {
					System.out.println(ConsoleColour.BLUE_BRIGHT);
					System.out.println("Select a filter: \n Options are:");
					filterName = Filter.getFilters();
				}
				case "3" -> {
					System.out.println(ConsoleColour.BLUE_BRIGHT);
					try {
						BufferedImage image = ImageIO.read(new File(imageName));
						kernel = Filter.getFilter(filterName);
						ImageConvolution.convolution(image, kernel);
					}
					catch(IOException e){
						System.out.println("error loading the file or filter, make sure you did menu #1 and #2 before");
					}

				}
				case "4" -> {
					System.out.println(ConsoleColour.BLUE_BRIGHT);
					System.out.println("The program is now exiting");
					System.out.println("press any key to exit");
					String exit = input.nextLine();
					menu = "4";
				}
				default -> {
					System.out.print(ConsoleColour.RED_BOLD_BRIGHT);
					System.out.println(menu + " is not a valid input, please enter a valid input.");
				}
			}
		}
		System.out.println(ConsoleColour.RESET);
	}

	private static void printMenu(){
		System.out.print(ConsoleColour.BLACK_BOLD_BRIGHT);
		System.out.println("1) Enter Image Name"); //Ask user to specify the file to process. Do NOT hardcode paths or file names
		System.out.println("2) Select a Filter"); //List the set of filters Available in the class Kernel.java
		System.out.println("3) Create new image"); //Add as many options to the menu as you like and feel free to restructure it in any way.
		System.out.println("4) Quit"); //Terminate
		System.out.println("\nSelect Option [1-4]>");
	}
}
