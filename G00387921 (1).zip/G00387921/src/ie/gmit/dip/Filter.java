package ie.gmit.dip;
import java.util.Locale;
import java.util.Scanner;

public class Filter {
    public static String getFilters(){
        boolean found = false;
        Scanner input = new Scanner(System.in);
        String[] filterList = {"IDENTITY","EDGE_DETECTION_1","EDGE_DETECTION_2","LAPLACIAN","SHARPEN",
                "VERTICAL_LINES","HORIZONTAL_LINES","DIAGONAL_45_LINES","BOX_BLUR","SOBEL_HORIZONTAL","SOBEL_VERTICAL"}; // to finish... can be moved to seperate file

        for(String filters : filterList) {
            System.out.print(filters + ", ");
        }
        String filter = input.nextLine();
        filter = filter.toLowerCase(); // allows input to not be case sensitive
        for(String filters : filterList) {
            filters = filters.toLowerCase(); // allows input to not be case sensitive
            if (filters.equals(filter)) {
                found = true;
                break;
            }
        }
        if(found){
            System.out.println("\nFilter has been found");
            return filter;
        }
        else {
            System.out.print(ConsoleColour.RED_BOLD_BRIGHT);
            System.out.println("Filter has not been found, try again");
            return null;
        }
    }
    public static double[][] getFilter(String filterName) {
        switch (filterName.toUpperCase()) {
            case "IDENTITY":
                return Kernel.IDENTITY;
            case "EDGE_DETECTION_1":
                return Kernel.EDGE_DETECTION_1;
            case "EDGE_DETECTION_2":
                return Kernel.EDGE_DETECTION_2;
            case "LAPLACIAN":
                return Kernel.LAPLACIAN;
            case "SHARPEN":
                return Kernel.SHARPEN;
            case "VERTICAL_LINES":
                return Kernel.VERTICAL_LINES;
            case "HORIZONTAL_LINES":
                return Kernel.HORIZONTAL_LINES;
            case "DIAGONAL_45_LINES":
                return Kernel.DIAGONAL_45_LINES;
            case "BOX_BLUR":
                return Kernel.BOX_BLUR;
            case "SOBEL_HORIZONTAL":
                return Kernel.SOBEL_HORIZONTAL;
            case "SOBEL_VERTICAL":
                return Kernel.SOBEL_VERTICAL;
            default:
                System.out.println("error getting filter.");
                return null;
        }
    }
}
