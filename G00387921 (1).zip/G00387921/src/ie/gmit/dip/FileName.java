package ie.gmit.dip;

import java.io.File;
import java.util.Scanner;

public class fileName {

    public static Scanner input = new Scanner(System.in);  // Create a Scanner object

    public static String setFileName(){
        String[] pathnames;
        String directory = "Images/";

        // Creates a new File instance by converting the given pathname string
        // into an abstract pathname
        File f = new File(directory);

        // Populates the array with names of files and directories
        pathnames = f.list();

        assert pathnames != null;
        System.out.println("Files available:");
        for (int i = 1; i < pathnames.length; i++) {
            System.out.println(pathnames[i]);
        }

        System.out.println("Enter Image name!");
        String imageName = input.nextLine();
        // For each pathname in the pathnames array

        boolean found = false;
        for (String pathname : pathnames) { //tries to find the filename in the images folder from what the user inputted
            if (pathname.equals(imageName)) {
                found = true;
                break;
            }
        }
        if(found){
            System.out.print(ConsoleColour.GREEN_BOLD_BRIGHT);
            System.out.println("image name has been accepted as: " + imageName + "\n");
            return directory + imageName;
            //to do
        }
        else {
            System.out.print(ConsoleColour.RED_BOLD_BRIGHT);
            System.out.println("invalid image name");
            return null;
        }

    }
}
