*************************************************************
*	Project: Image Filtering System                     *
*	Author:  Jolita Budriene G00387921                  *
*	Course:  H. Dip in Software Development             *
*************************************************************

I used Java 16.0.1
-------------------
Project Description
-------------------
1. Applies a selected filter to a selected image and then saves the output as a separate file.

2. For program to work correctly: 
You have to create an images inside the src folder.

3. Runner class:
This is the class that gets run which prints a menu where the user can select what option to do. The user can choose to select the filter or image first and by using the menu can also change it if they change their mind.

4. FileName class: 
Prints all the files in the Images folder and asks the user to choose one of the files. You need to create this folder outside the src directory.

5. Filter class: 
Prints out all the filters and then asks the user to select one, the input does not need to be case sensitive. Once a filter gets chosen it returns an array from the Kernel class.

6. Kernel Class: 
This holds all the arrays that are used to change the image.

7. ImageConvolution: 
This class takes both the filter array and image name to apply the filter to the file name which then gets outputted as output.png 

8. ConsoleColour: //ANSI ESCAPE CODES
This class shows colours, saves the values of the�ConsoleColor�enumeration to an array and stores the current values of the BackgroundColor and ForegroundColor properties to variables. Changes the foreground color to each color in the ConsoleColor enumeration except to the color that matches the current background, and it changes the background color to each color in the ConsoleColor enumeration exept to the color that matches the current foreground.
Finally, it calls the�ResetColor�method to restore the original console colors.(https://docs.microsoft.com/en-us/dotnet/api/system.consolecolor?view=net-5.0)

-------------------
HOW TO USE:
-------------------
* Unzip folder.
* To run the compiled code use> java ie.gmit.dip.Runner			

